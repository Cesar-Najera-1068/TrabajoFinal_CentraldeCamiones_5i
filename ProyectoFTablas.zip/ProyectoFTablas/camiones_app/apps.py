from django.apps import AppConfig


class CamionesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'camiones_app'
