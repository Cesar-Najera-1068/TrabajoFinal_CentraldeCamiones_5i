from django.contrib import admin
from .models import Viajes
# Register your models here.
admin.site.register(Viajes)