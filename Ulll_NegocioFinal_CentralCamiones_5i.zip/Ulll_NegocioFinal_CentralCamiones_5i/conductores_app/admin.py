from django.contrib import admin
from .models import Conductores
# Register your models here.
admin.site.register(Conductores)